#include <stdio.h>

int main()
{
    int s, m, h, s2, restoh, restom;
    scanf("%d", &s);
    h=s/3600;
    restoh=s%3600;
    m=restoh/60;
    restom=restoh%60;
    s2=restom;
    printf("%d:%d:%d\n", h, m, s2);

    return 0;
}
